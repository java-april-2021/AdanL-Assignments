package com.AdanLara.Books.Repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.AdanLara.Books.Models.Book;

public interface BookRepository extends CrudRepository <Book, Long>{
	//gives an array list of all books in DB
	List <Book> findAll();
	
	List<Book> findByDescriptionContaining(String search);
	
	//counts how many books have a certain string
	Long countByTitleContaining(String search);
	
	//will delete a book by a string in title
	Long deleteByTitleStartingWith(String search);
	

}
