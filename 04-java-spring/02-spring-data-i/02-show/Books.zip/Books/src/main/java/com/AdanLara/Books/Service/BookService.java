package com.AdanLara.Books.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.AdanLara.Books.Models.Book;
import com.AdanLara.Books.Repository.BookRepository;

@Service
public class BookService {
	private BookRepository bRepo;

	public BookService(BookRepository bRepo) {
		this.bRepo = bRepo;
	}
	
	//get all
	public List<Book> getAll(){
		return bRepo.findAll();
	}
	
	//create
	public Book createBook(Book b) {
		return bRepo.save(b);
	}
	
	//Retrieve book
	
	public Book retriveBook(Long id) {
		return this.bRepo.findById(id).orElse(null);
	}
}
