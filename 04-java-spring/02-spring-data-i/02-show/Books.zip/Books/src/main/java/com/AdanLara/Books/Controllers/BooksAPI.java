package com.AdanLara.Books.Controllers;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.AdanLara.Books.Models.Book;
import com.AdanLara.Books.Service.BookService;

@RestController
public class BooksAPI {
	private final BookService bService;

	public BooksAPI(BookService bService) {
		this.bService = bService;
	}
	//all book
	@RequestMapping("/api/books")
	public List<Book> allBook(){
		return this.bService.getAll();
	}
	//create a book
	@PostMapping("api/books")
	public Book create(@RequestParam(value="title") String title, @RequestParam(value="description") String desc, @RequestParam(value="language") String lang, @RequestParam(value="pages") Integer numOfPages){
        Book book = new Book(title, desc, lang, numOfPages);
		return bService.createBook(book);
	}
	//show 1 book
	@RequestMapping("api/books/{id}")
	public Book show(@PathVariable("id") Long id ) {
		Book book = bService.retriveBook(id);
		return book;
	}
}
