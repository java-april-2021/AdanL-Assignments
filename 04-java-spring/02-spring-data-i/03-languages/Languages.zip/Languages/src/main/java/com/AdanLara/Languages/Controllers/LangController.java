package com.AdanLara.Languages.Controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.AdanLara.Languages.Models.Language;
import com.AdanLara.Languages.Service.LanguageService;

@Controller
public class LangController {
	@Autowired
	private LanguageService lService;
	
	//main page
	@GetMapping("/")
	public String mainpage(@ModelAttribute("language") Language language, Model viewModel){
		List<Language> langs = lService.getAll();
		viewModel.addAttribute("langs", langs);
		return "Index.jsp";
	}
	//adding
	@PostMapping("/")
	public String addLang(@Valid @ModelAttribute("language") Language language, BindingResult result, Model viewModel) {
		if(result.hasErrors()) {
			List<Language> langs = lService.getAll();
			viewModel.addAttribute("langs", langs);
			return "/Index.jsp";
		}
		else {
			lService.saveLang(language);
			return "redirect:/";
		}
	}
	//edit
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Long id, Model viewModel) {
		Language lang =lService.getLang(id);
		if(lang!=null) {
			viewModel.addAttribute("language", lang);
			return "/edit.jsp";
		}
		else { return "redirect:/";
		}
	}
	@PutMapping("/edit/{id}")
	public String update(@PathVariable("id") Long id, Language language) {
		this.lService.saveLang(language);
		return "redirect:/";
	}
	
	//get one
	@GetMapping("/{id}")
	public String display(@PathVariable("id") Long id, Model viewModel) {
		Language lang= lService.getLang(id);
		viewModel.addAttribute("language", lang);
		return "/Display.jsp";
	}
	//Delete
	@GetMapping("delete/{id}")
	public String delete(@PathVariable("id") Long id) {
		this.lService.deleteLang(id);
		return "redirect:/";
	}
}
