package com.AdanLara.Languages.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AdanLara.Languages.Models.Language;
import com.AdanLara.Languages.Repository.LanguageRepository;

@Service
public class LanguageService {
	@Autowired
	private LanguageRepository lRepo;
	
	//get all
	public List<Language> getAll() {
		return this.lRepo.findAll();
	}
	//get one
	public Language getLang(Long id) {
		return this.lRepo.findById(id).orElse(null);
	}
	//delete
	public void deleteLang(Long id) {
		this.lRepo.deleteById(id);
	}
	//update and save
	public Language saveLang(Language lang) {
		return this.lRepo.save(lang);
	}
	
}
